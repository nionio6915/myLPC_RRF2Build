These are the Windows device driver files for Duet electronics running RepRapFirmware 1.12 and later.

Due to the difficulties of downloading text files from github without the line endings getting changed (which messes up the digital signature), I recommend you download the Zip file and extract the contents to a folder on your PC.
